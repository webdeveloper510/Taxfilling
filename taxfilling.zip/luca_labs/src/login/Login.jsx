import React from 'react'

const Login = () => {
    return (
        <>
            <div className='container m-auto my-20'>
                <div className='w-full'>
                    <div className='flex '>
                        <div className='lg:w-[7%]'></div>
                        <div className='lg:w-[43%]'>
                            <form action="" className=''>
                                <h1 className='text-5xl text-[#325965] font-bold'>Log in to Luca Accounting
                                </h1>

                                <div className='py-8 w-[80%]'>
                                    <label
                                        htmlFor="UserEmail"
                                        className="block overflow-hidden rounded-md border border-gray-200 px-3 shadow-sm focus-within:border-blue-600 focus-within:ring-1 focus-within:ring-blue-600"
                                    >
                                        <span className="text-xs font-medium text-gray-700"> Email </span>

                                        <input
                                            type="email"
                                            id="UserEmail"
                                            placeholder="anthony@rhcp.com"
                                            className="mb-2 w-full border-none p-0 focus:border-transparent focus:outline-none focus:ring-0 sm:text-sm"
                                        />
                                    </label>
                                    <label
                                        htmlFor="password"
                                        className="relative mt-4 block overflow-hidden rounded-md border border-gray-200 px-3 shadow-sm focus-within:border-blue-600 focus-within:ring-1 focus-within:ring-blue-600"
                                    >
                                        <span className="text-xs font-medium text-gray-700"> Password </span>

                                        <input
                                            type="password"
                                            id="password"
                                            placeholder="password"
                                            className="relative mb-2 w-full border-none p-0 focus:border-transparent focus:outline-none focus:ring-0 sm:text-sm"
                                        />
                                        <svg className='absolute  top-5 right-4 pl-2 w-[30px] h-[30px] fill-[#104649]  icon_border' xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512"><path d="M288 80c-65.2 0-118.8 29.6-159.9 67.7C89.6 183.5 63 226 49.4 256c13.6 30 40.2 72.5 78.6 108.3C169.2 402.4 222.8 432 288 432s118.8-29.6 159.9-67.7C486.4 328.5 513 286 526.6 256c-13.6-30-40.2-72.5-78.6-108.3C406.8 109.6 353.2 80 288 80zM95.4 112.6C142.5 68.8 207.2 32 288 32s145.5 36.8 192.6 80.6c46.8 43.5 78.1 95.4 93 131.1c3.3 7.9 3.3 16.7 0 24.6c-14.9 35.7-46.2 87.7-93 131.1C433.5 443.2 368.8 480 288 480s-145.5-36.8-192.6-80.6C48.6 356 17.3 304 2.5 268.3c-3.3-7.9-3.3-16.7 0-24.6C17.3 208 48.6 156 95.4 112.6zM288 336c44.2 0 80-35.8 80-80s-35.8-80-80-80c-.7 0-1.3 0-2 0c1.3 5.1 2 10.5 2 16c0 35.3-28.7 64-64 64c-5.5 0-10.9-.7-16-2c0 .7 0 1.3 0 2c0 44.2 35.8 80 80 80zm0-208a128 128 0 1 1 0 256 128 128 0 1 1 0-256z" /></svg>
                                    </label>
                                </div>
                                <div className='w-[80%] flex justify-between'>

                                    <button className='bg-[#90EE90] text-[#325965] text-sm font-bold py-2 px-8 rounded-t-2xl rounded-b-2xl	'>Sign In</button>
                                    <h6 className='text-[#325965] font-bold text-sm pt-2.5'><a href="/forgot">Forgot your password?</a></h6>
                                </div>
                                <div className='w-[80%] flex justify-between my-8 gap-3'>
                                    <div className='w-[50%] flex px-4 py-2 gap-1 Google_btn'>
                                        <img src="image 11.png" alt="" />
                                        <h6 className='text-[#325965] font-bold text-sm pt-1'>Sign In With Google
                                        </h6>
                                    </div>
                                    <div className='w-[50%] flex px-4 py-2 gap-1 Google_btn'>
                                        <img src="pngegg (2) 1.png" alt="" />
                                        <h6 className='text-[#325965] font-bold text-sm pt-1'>Sign In With Facebook
                                        </h6>
                                    </div>
                                </div>
                                <h6 className='text-[#325965] text-sm font-bold'>Don’t have a user? <span className='text-[#90EE90]'>Register</span>
                                    </h6>
                            </form>
                        </div>
                        <div className='lg:w-[43%]'>
                            <img src="image 1.png" alt="" />
                        </div>
                        <div className='lg:w-[7%]'></div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default Login