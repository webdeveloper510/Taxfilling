import React from 'react'

const Forgot = () => {
    return (
        <>
            <div className='container m-auto my-20'>
                <div className='w-full'>
                    <div className='flex '>
                        <div className='lg:w-[7%]'></div>
                        <div className='lg:w-[43%]'>
                            <form action="" className='my-10'>
                                <div className='w-[60%]'>
                                    <h1 className='text-5xl text-[#325965] font-bold'>Forgot
                                        Password
                                    </h1>
                                    <p className='py-5 text-sm text-[#727272] font-medium'>
                                        If you have <strong>forgotten your password</strong>, we can help you create a new one. Enter your user's email address and we'll send you a link.
                                    </p>
                                </div>

                                <div className='py-5 w-[80%]'>
                                    <label
                                        htmlFor="UserEmail"
                                        className="block overflow-hidden rounded-md border border-gray-200 px-3 shadow-sm focus-within:border-blue-600 focus-within:ring-1 focus-within:ring-blue-600"
                                    >
                                        <span className="text-xs font-medium text-gray-700"> Email ID </span>

                                        <input
                                            type="email"
                                            id="UserEmail"
                                            placeholder="peter21williams@gmail.com"
                                            className="mb-2 w-full border-none p-0 focus:border-transparent focus:outline-none focus:ring-0 sm:text-sm"
                                        />
                                    </label>

                                </div>
                                <div className='w-[80%] flex justify-between'>

                                    <button className='bg-[#90EE90] text-[#325965] text-sm font-bold py-2 px-8 rounded-t-2xl rounded-b-2xl	'>Send Link</button>
                                </div>

                                <h6 className='text-[#325965] text-sm font-bold py-5 pl-4'> <span className='text-[#90EE90]'><a href="/login">Back to Login</a></span>
                                </h6>
                            </form>
                        </div>
                        <div className='lg:w-[43%]'>
                            <img src="image 1.png" alt="" />
                        </div>
                        <div className='lg:w-[7%]'></div>
                    </div>
                </div>
            </div>

        </>
    )
}

export default Forgot