import ReactDOM from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import RoutesUrl from './routes/routes';
import Header from "./components/navbar/Navbar";
import Footer from "./components/footer/Footer";
function App() {
  return (
    <>
      <BrowserRouter>
        <Header />
        < RoutesUrl />
        <Footer />
      </BrowserRouter>
    </>
  );
}

export default App;
