import React from 'react'

const Home = () => {
  return (
    <>
      <section>
        <div className='container m-auto my-20'>
          <div className='w-full'>
            <div className='home_background m-auto pt-16'>
              <h3 className='lg:w-[60%] w-full bg-[#FFE4B5] rounded-lg home_heading text-center  m-auto text-[#325965] text-sm font-normal py-1.5'>Start a sole proprietorship or limited liability company with Luca Labs.
              </h3>
              <h1 className='lg:w-[90%] w-full text-[#325965] font-bold lg:text-5xl m-auto text-center py-7'>Smart and simple accounting program
              </h1>
              <p className='lg:w-[50%] w-full text-[#727272] font-noemal text-sm m-auto text-center'>
                Luca Labs makes accounting easier, so you can spend your time on what you do best.
              </p>
              <div className='lg:w-[80%] w-full lg:flex justify-between	m-auto py-5'>
                <h5 className='text-[#000000] text-lg font-bold opacity-75'>Everything you need, in one place.</h5>
                <h6 className='text-[#000000] text-lg font-bold opacity-75'> Over <span className='text-[#325965] text-lg font-normal'>60,000</span> satisfied customers.</h6>
              </div>
              <div className='m-auto flex justify-center'>
                <button className='py-5 lg:w-[30%] w-full'>
                  <a
                    className="group inline-block rounded-full bg-gradient-to-r from-[#90EE90] via-[#90EE90] to-[#90EE90]  hover:text-white focus:outline-none  active:text-opacity-75"
                    href="#"
                  >
                    <span
                      className="block rounded-full bg-[#90EE90] text-[#325965] lg:px-6 lg:py-3 text-sm font-bold group-hover:bg-transparent"
                    >
                      Try free for 30 days
                    </span>
                  </a>
                </button>
              </div>
              <h6 className='text-[#325965] text-sm font-bold text-center'>Non-binding trial period
              </h6>
            </div>
          </div>
        </div>
      </section>
      <section>
        <div className='container m-auto my-20'>
          <div className='w-full'>
            <div className='text-center'>
              <h1 className='text-[#325965] font-bold text-5xl'>Prices adapted to small businesses</h1>
              <p className='lg:w-[30%] w-full m-auto py-4 text-[#727272] text-lg font-normal'>For far too long, small businesses have paid too much for accounting software.
              </p>
            </div>
            <div className='flex m-auto gap-5 py-10'>
              <div className='w-[10%]'>
              </div>
              <div className='lg:w-[27%] bg-[#F0EDE8] p-5 rounded-t-2xl	rounded-b-2xl	'>
                <div className='bg-[#fff] p-3 rounded-lg'>
                  <h6 className='text-[#325965] text-lg font-bold'>Basic</h6>
                  <p className='text-[#325965] font-bold text-6xl'>25<span className='text-[#325965] font-bold text-sm pl-0.5 '>per month</span></p>
                </div>
                <label htmlFor="" className="flex cursor-pointer items-start py-2">
                  <div className="flex items-center w-[20px] h-[20px] rounded-full relative pt-1">
                    &#8203;
                    <input type="checkbox" className="w-[18px] h-[18px] rounded-full border-gray-300 absolute	" id="Option1" />
                    <svg className=" w-[12px] h-[12px] absolute left-1 fill-[#ccc]" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path d="M438.6 105.4c12.5 12.5 12.5 32.8 0 45.3l-256 256c-12.5 12.5-32.8 12.5-45.3 0l-128-128c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0L160 338.7 393.4 105.4c12.5-12.5 32.8-12.5 45.3 0z" /></svg>
                  </div>
                  <div className='pl-2'>
                    <strong className="font-medium text-[#141414] text-[13px]">Honest and low monthly price</strong>
                  </div>
                </label>
                <label htmlFor="" className="flex cursor-pointer items-start gap-2 py-2">
                  <div className="flex items-center w-[20px] h-[20px] rounded-full relative pt-1">
                    &#8203;
                    <input type="checkbox" className="w-[18px] h-[18px] rounded-full border-gray-300 absolute	" id="Option1" />
                    <svg className=" w-[12px] h-[12px] absolute left-1 fill-[#ccc]" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path d="M438.6 105.4c12.5 12.5 12.5 32.8 0 45.3l-256 256c-12.5 12.5-32.8 12.5-45.3 0l-128-128c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0L160 338.7 393.4 105.4c12.5-12.5 32.8-12.5 45.3 0z" /></svg>
                  </div>
                  <div className='pl-2'>
                    <strong className="font-medium text-[#141414] text-[13px]">Everything you need to run daily accounting and invoicing</strong>
                  </div>
                </label>
                <label htmlFor="" className="flex cursor-pointer items-start gap-2 py-2">
                  <div className="flex items-center w-[20px] h-[20px] rounded-full relative pt-1">
                    &#8203;
                    <input type="checkbox" className="w-[18px] h-[18px] rounded-full border-gray-300 absolute	" id="Option1" />
                    <svg className=" w-[12px] h-[12px] absolute left-1 fill-[#ccc]" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path d="M438.6 105.4c12.5 12.5 12.5 32.8 0 45.3l-256 256c-12.5 12.5-32.8 12.5-45.3 0l-128-128c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0L160 338.7 393.4 105.4c12.5-12.5 32.8-12.5 45.3 0z" /></svg>
                  </div>
                  <div className='pl-2'>
                    <strong className="font-medium text-[#141414] text-[13px]">No hidden costs per voucher, per invoice or similar</strong>
                  </div>
                </label>
                <label htmlFor="Option4" className="flex cursor-pointer items-start gap-2 py-2">
                  <div className="flex items-center w-[20px] h-[20px] rounded-full relative pt-1">
                    &#8203;
                    <input type="checkbox" className="w-[18px] h-[18px] rounded-full border-gray-300 absolute	" id="Option1" />
                    <svg className=" w-[12px] h-[12px] absolute left-1 fill-[#ccc]" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path d="M438.6 105.4c12.5 12.5 12.5 32.8 0 45.3l-256 256c-12.5 12.5-32.8 12.5-45.3 0l-128-128c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0L160 338.7 393.4 105.4c12.5-12.5 32.8-12.5 45.3 0z" /></svg>
                  </div>
                  <div className='pl-2'>
                    <strong className="font-medium text-[#141414] text-[13px]">Price requires an annual agreement, otherwise NOK 129 per month</strong>
                  </div>
                </label>
                <button className='bg-[#325965] p-2.5 text-[#fff] w-[100%] rounded-t-3xl	rounded-b-3xl	mt-2'>Try for free now!</button>

              </div>
              <div className='lg:w-[27%] bg-[#F0EDE8] p-5 rounded-t-2xl	rounded-b-2xl	'>
                <div className='bg-[#fff] p-3 rounded-lg'>
                  <h6 className='text-[#325965] text-lg font-bold'>Premium</h6>
                  <p className='text-[#90EE90] font-bold text-6xl'>105<span className='text-[#90EE90] font-bold text-sm pl-0.5 '>per month</span></p>
                </div>
                <label htmlFor="" className="flex cursor-pointer items-start py-2">
                  <div className="flex items-center w-[20px] h-[20px] rounded-full relative pt-1">
                    &#8203;
                    <input type="checkbox" className="w-[18px] h-[18px] rounded-full border-gray-300 absolute	" id="Option1" />
                    <svg className=" w-[12px] h-[12px] absolute left-1 fill-[#ccc]" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path d="M438.6 105.4c12.5 12.5 12.5 32.8 0 45.3l-256 256c-12.5 12.5-32.8 12.5-45.3 0l-128-128c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0L160 338.7 393.4 105.4c12.5-12.5 32.8-12.5 45.3 0z" /></svg>
                  </div>
                  <div className='pl-2'>
                    <strong className="font-medium text-[#141414] text-[13px]">Honest and low monthly price</strong>
                  </div>
                </label>
                <label htmlFor="" className="flex cursor-pointer items-start gap-2 py-2">
                  <div className="flex items-center w-[20px] h-[20px] rounded-full relative pt-1">
                    &#8203;
                    <input type="checkbox" className="w-[18px] h-[18px] rounded-full border-gray-300 absolute	" id="Option1" />
                    <svg className=" w-[12px] h-[12px] absolute left-1 fill-[#ccc]" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path d="M438.6 105.4c12.5 12.5 12.5 32.8 0 45.3l-256 256c-12.5 12.5-32.8 12.5-45.3 0l-128-128c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0L160 338.7 393.4 105.4c12.5-12.5 32.8-12.5 45.3 0z" /></svg>
                  </div>
                  <div className='pl-2'>
                    <strong className="font-medium text-[#141414] text-[13px]">Everything you need to run daily accounting and invoicing</strong>
                  </div>
                </label>
                <label htmlFor="" className="flex cursor-pointer items-start gap-2 py-2">
                  <div className="flex items-center w-[20px] h-[20px] rounded-full relative pt-1">
                    &#8203;
                    <input type="checkbox" className="w-[18px] h-[18px] rounded-full border-gray-300 absolute	" id="Option1" />
                    <svg className=" w-[12px] h-[12px] absolute left-1 fill-[#ccc]" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path d="M438.6 105.4c12.5 12.5 12.5 32.8 0 45.3l-256 256c-12.5 12.5-32.8 12.5-45.3 0l-128-128c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0L160 338.7 393.4 105.4c12.5-12.5 32.8-12.5 45.3 0z" /></svg>
                  </div>
                  <div className='pl-2'>
                    <strong className="font-medium text-[#141414] text-[13px]">No hidden costs per voucher, per invoice or similar</strong>
                  </div>
                </label>
                <label htmlFor="" className="flex cursor-pointer items-start gap-2 py-2">
                  <div className="flex items-center w-[20px] h-[20px] rounded-full relative pt-1">
                    &#8203;
                    <input type="checkbox" className="w-[18px] h-[18px] rounded-full border-gray-300 absolute	" id="Option1" />
                    <svg className=" w-[12px] h-[12px] absolute left-1 fill-[#ccc]" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path d="M438.6 105.4c12.5 12.5 12.5 32.8 0 45.3l-256 256c-12.5 12.5-32.8 12.5-45.3 0l-128-128c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0L160 338.7 393.4 105.4c12.5-12.5 32.8-12.5 45.3 0z" /></svg>
                  </div>
                  <div className='pl-2'>
                    <strong className="font-medium text-[#141414] text-[13px]">Price requires an annual agreement, otherwise NOK 129 per month</strong>
                  </div>
                </label>
                <button className='bg-[#90EE90] p-2.5 text-[#fff] w-[100%] rounded-t-3xl	rounded-b-3xl	mt-2'>Try for free now!</button>

              </div>
              <div className='lg:w-[27%] bg-[#F0EDE8] p-5 rounded-t-2xl	rounded-b-2xl	'>
                <div className='bg-[#fff] p-3 rounded-lg'>
                  <h6 className='text-[#325965] text-lg font-bold'>Platinum</h6>
                  <p className='text-[#90EE90] font-bold text-6xl'>200<span className='text-[#90EE90] font-bold text-sm pl-0.5 '>per month</span></p>
                </div>
                <label htmlFor="" className="flex cursor-pointer items-start py-2">
                  <div className="flex items-center w-[20px] h-[20px] rounded-full relative pt-1">
                    &#8203;
                    <input type="checkbox" className="w-[18px] h-[18px] rounded-full border-gray-300 absolute	" id="Option1" />
                    <svg className=" w-[12px] h-[12px] absolute left-1 fill-[#ccc]" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path d="M438.6 105.4c12.5 12.5 12.5 32.8 0 45.3l-256 256c-12.5 12.5-32.8 12.5-45.3 0l-128-128c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0L160 338.7 393.4 105.4c12.5-12.5 32.8-12.5 45.3 0z" /></svg>
                  </div>
                  <div className='pl-2'>
                    <strong className="font-medium text-[#141414] text-[13px]">Honest and low monthly price</strong>
                  </div>
                </label>
                <label htmlFor="" className="flex cursor-pointer items-start gap-2 py-2">
                  <div className="flex items-center w-[20px] h-[20px] rounded-full relative pt-1">
                    &#8203;
                    <input type="checkbox" className="w-[18px] h-[18px] rounded-full border-gray-300 absolute	" id="Option1" />
                    <svg className=" w-[12px] h-[12px] absolute left-1 fill-[#ccc]" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path d="M438.6 105.4c12.5 12.5 12.5 32.8 0 45.3l-256 256c-12.5 12.5-32.8 12.5-45.3 0l-128-128c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0L160 338.7 393.4 105.4c12.5-12.5 32.8-12.5 45.3 0z" /></svg>
                  </div>
                  <div className='pl-2'>
                    <strong className="font-medium text-[#141414] text-[13px]">Everything you need to run daily accounting and invoicing</strong>
                  </div>
                </label>
                <label htmlFor="" className="flex cursor-pointer items-start gap-2 py-2">
                  <div className="flex items-center w-[20px] h-[20px] rounded-full relative pt-1">
                    &#8203;
                    <input type="checkbox" className="w-[18px] h-[18px] rounded-full border-gray-300 absolute	" id="Option1" />
                    <svg className=" w-[12px] h-[12px] absolute left-1 fill-[#ccc]" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path d="M438.6 105.4c12.5 12.5 12.5 32.8 0 45.3l-256 256c-12.5 12.5-32.8 12.5-45.3 0l-128-128c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0L160 338.7 393.4 105.4c12.5-12.5 32.8-12.5 45.3 0z" /></svg>
                  </div>
                  <div className='pl-2'>
                    <strong className="font-medium text-[#141414] text-[13px]">No hidden costs per voucher, per invoice or similar</strong>
                  </div>
                </label>
                <label htmlFor="" className="flex cursor-pointer items-start gap-2 py-2">
                  <div className="flex items-center w-[20px] h-[20px] rounded-full relative pt-1">
                    &#8203;
                    <input type="checkbox" className="w-[18px] h-[18px] rounded-full border-gray-300 absolute	" id="Option1" />
                    <svg className=" w-[12px] h-[12px] absolute left-1 fill-[#ccc]" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path d="M438.6 105.4c12.5 12.5 12.5 32.8 0 45.3l-256 256c-12.5 12.5-32.8 12.5-45.3 0l-128-128c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0L160 338.7 393.4 105.4c12.5-12.5 32.8-12.5 45.3 0z" /></svg>
                  </div>
                  <div className='pl-2'>
                    <strong className="font-medium text-[#141414] text-[13px]">Price requires an annual agreement, otherwise NOK 129 per month</strong>
                  </div>
                </label>
                <button className='bg-[#90EE90] p-2.5 text-[#fff] w-[100%] rounded-t-3xl	rounded-b-3xl	mt-2'>Try for free now!</button>
              </div>
              <div className='w-[10%]'>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section>
        <div className='container m-auto my-20'>
          <div className='w-full'>
            <div className='lg:flex '>
              <div className='w-[7%]'></div>
              <div className='lg:w-[30%] w-full p-5'>
                <h2 className='text-[#325965] font-bold text-4xl'>Small</h2>
                <h3 className='text-[#90EE90] font-bold text-4xl'>businessesLove</h3>
                <h4 className='text-[#325965] font-bold text-4xl'>Luca Labs</h4>
                <p className='text-[#727272] text-lg font-normal py-5'><strong>What do people who use Luca say?</strong> Easy to get started and easy to like! Just what you need - without complex things that make the job cumbersome.</p>
              </div>
              <div className='lg:w-[60%] w-full p-5'>
                <h5 className='text-[#727272] font-normal text-lg p-2'>Unlimited invoicing, seamless reporting and everything you expect from a smart and modern system.</h5>
                <div className='flex gap-4 py-2 justify-center	'>
                  <div className=' bg-[#F0EDE8]  w-[320px] rounded-t-2xl	rounded-b-2xl p-5'>
                    <div className='flex justify-between'>
                      <h5 className='text-[#31263F] font-bold text-sm'>Tatiana Penzo</h5>
                      <p className='flex text-[#141414] text-[12px] font-normal'>
                        <span><svg className='w-[12px] h-[12px] fill-[#FFA500] mt-0.5 mr-1' xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512"><path d="M316.9 18C311.6 7 300.4 0 288.1 0s-23.4 7-28.8 18L195 150.3 51.4 171.5c-12 1.8-22 10.2-25.7 21.7s-.7 24.2 7.9 32.7L137.8 329 113.2 474.7c-2 12 3 24.2 12.9 31.3s23 8 33.8 2.3l128.3-68.5 128.3 68.5c10.8 5.7 23.9 4.9 33.8-2.3s14.9-19.3 12.9-31.3L438.5 329 542.7 225.9c8.6-8.5 11.7-21.2 7.9-32.7s-13.7-19.9-25.7-21.7L381.2 150.3 316.9 18z" /></svg>
                        </span>
                        4.2</p>
                    </div>
                    <h5 className='text-[#141414] text-sm font-normal'>Course and lecturer</h5>
                    <p className='text-[#141414] text-sm font-normal py-3'>Finally, an accounting system that is excellent for small AS. Incredibly simple, clear and actually also motivating. LoveLucaLabs ❤️</p>
                  </div>
                  <div className=' bg-[#F0EDE8] w-[320px] rounded-t-2xl	rounded-b-2xl p-5'>
                    <div className='flex justify-between'>
                      <h5 className='text-[#31263F] font-bold text-sm'>Terje Børstad</h5>
                      <p className='flex text-[#141414] text-[12px] font-normal'>
                        <span><svg className='w-[12px] h-[12px] fill-[#FFA500] mt-0.5 mr-1' xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512"><path d="M316.9 18C311.6 7 300.4 0 288.1 0s-23.4 7-28.8 18L195 150.3 51.4 171.5c-12 1.8-22 10.2-25.7 21.7s-.7 24.2 7.9 32.7L137.8 329 113.2 474.7c-2 12 3 24.2 12.9 31.3s23 8 33.8 2.3l128.3-68.5 128.3 68.5c10.8 5.7 23.9 4.9 33.8-2.3s14.9-19.3 12.9-31.3L438.5 329 542.7 225.9c8.6-8.5 11.7-21.2 7.9-32.7s-13.7-19.9-25.7-21.7L381.2 150.3 316.9 18z" /></svg>
                        </span>
                        4.2</p>
                    </div>
                    <h5 className='text-[#141414] text-sm font-normal'>Guitar teacher</h5>
                    <p className='text-[#141414] text-sm font-normal py-3'>Super simple and efficient invoicing! Cool with Vipps invoice that makes it easy for my customers to pay me quickly.</p>
                  </div>
                </div>
              </div>
              <div className='w-[7%]'></div>
            </div>
          </div>
        </div>
      </section>
      <section>
        <div className='container m-auto'>
          <div className='w-full'>
            <div className='lg:flex  justify-center '>
              <div className='w-[10%]'></div>
              <div className='w-[40%]  home_background_image1 m-auto'>
                <h1 className='w-[90%] text-6xl font-bold text-[#325965] pt-24 float-right	'> Send An <span className='text-[#90EE90]'>Invoice</span> Easily!</h1>
              </div>
              <div className='w-[40%] pt-24 pl-10'>
                <div className='lg:flex py-2'>
                  <div className='w-[14px] h-[14px] bg-[#FFA500] rounded-md mt-1'>
                    <svg className='w-[10px] h-[10px] fill-[#fff] pt-1 pl-1' xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 512A256 256 0 1 0 256 0a256 256 0 1 0 0 512z" /></svg>
                  </div>
                  <p className='text-sm text-[#727272] font-normal ml-2'>Send an invoice easily</p>
                </div>
                <div className='lg:flex py-2'>
                  <div className='w-[14px] h-[14px] bg-[#FFA500] rounded-md mt-1'>
                    <svg className='w-[10px] h-[10px] fill-[#fff] pt-1 pl-1' xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 512A256 256 0 1 0 256 0a256 256 0 1 0 0 512z" /></svg>
                  </div>
                  <p className='text-sm text-[#727272] font-normal ml-2'>Get paid quickly</p>
                </div>
                <div className='lg:flex py-2'>
                  <div className='w-[14px] h-[14px] bg-[#FFA500] rounded-md mt-1 '>
                    <svg className='w-[10px] h-[10px] fill-[#fff] pt-1 pl-1' xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 512A256 256 0 1 0 256 0a256 256 0 1 0 0 512z" /></svg>
                  </div>
                  <p className='text-sm text-[#727272] font-normal ml-2'>No restrictions or hidden costs</p>
                </div>
                <button className='my-2 px-4 py-2 bg-[#90EE90] text-[#325965] text-sm font-bold rounded-t-2xl	rounded-b-2xl	'>Read more about invoicing</button>

              </div>
              <div className='w-[10%]'></div>
            </div>
          </div>
        </div>
      </section>
      <section>
        <div className='container m-auto'>
          <div className='w-full'>
          <div className='lg:flex  justify-center '>
              <div className='w-[10%]'></div>
              <div className='w-[40%] pt-20'>
               <div className='float-right	pr-20'>
               <div className='lg:flex py-2'>
                  <div className='w-[14px] h-[14px] bg-[#FFA500] rounded-md mt-1'>
                    <svg className='w-[10px] h-[10px] fill-[#fff] pt-1 pl-1' xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 512A256 256 0 1 0 256 0a256 256 0 1 0 0 512z" /></svg>
                  </div>
                  <p className='text-sm text-[#727272] font-normal ml-2'>Send an invoice easily</p>
                </div>
                <div className='lg:flex py-2'>
                  <div className='w-[14px] h-[14px] bg-[#FFA500] rounded-md mt-1'>
                    <svg className='w-[10px] h-[10px] fill-[#fff] pt-1 pl-1' xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 512A256 256 0 1 0 256 0a256 256 0 1 0 0 512z" /></svg>
                  </div>
                  <p className='text-sm text-[#727272] font-normal ml-2'>Get paid quickly</p>
                </div>
                <div className='lg:flex py-2'>
                  <div className='w-[14px] h-[14px] bg-[#FFA500] rounded-md mt-1 '>
                    <svg className='w-[10px] h-[10px] fill-[#fff] pt-1 pl-1' xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 512A256 256 0 1 0 256 0a256 256 0 1 0 0 512z" /></svg>
                  </div>
                  <p className='text-sm text-[#727272] font-normal ml-2'>No restrictions or hidden costs</p>
                </div>
                <button className='my-2 px-4 py-2 bg-[#90EE90] text-[#325965] text-sm font-bold rounded-t-2xl	rounded-b-2xl	'>Read more about invoicing</button>
               </div>
               
              </div>
              <div className='w-[40%]  home_background_image2'>
                <h1 className='w-[90%] text-6xl font-bold text-[#325965] pt-24 '> Send An <span className='text-[#90EE90]'>Invoice</span> Easily!</h1>
              </div>
              <div className='w-[10%]'></div>
            </div>
          </div>
        </div>
      </section>
      <section>
        <div className='container m-auto '>
          <div className='w-full'>
            <div className='lg:flex  justify-center '>
              <div className='w-[10%]'></div>
              <div className='w-[40%]  home_background_image3 m-auto'>
                <h1 className='w-[90%] text-6xl font-bold text-[#325965] pt-24 float-right	'> Send An <span className='text-[#90EE90]'>Invoice</span> Easily!</h1>
              </div>
              <div className='w-[40%] pt-24 pl-10'>
                <div className='lg:flex py-2'>
                  <div className='w-[14px] h-[14px] bg-[#FFA500] rounded-md mt-1'>
                    <svg className='w-[10px] h-[10px] fill-[#fff] pt-1 pl-1' xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 512A256 256 0 1 0 256 0a256 256 0 1 0 0 512z" /></svg>
                  </div>
                  <p className='text-sm text-[#727272] font-normal ml-2'>Send an invoice easily</p>
                </div>
                <div className='lg:flex py-2'>
                  <div className='w-[14px] h-[14px] bg-[#FFA500] rounded-md mt-1'>
                    <svg className='w-[10px] h-[10px] fill-[#fff] pt-1 pl-1' xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 512A256 256 0 1 0 256 0a256 256 0 1 0 0 512z" /></svg>
                  </div>
                  <p className='text-sm text-[#727272] font-normal ml-2'>Get paid quickly</p>
                </div>
                <div className='lg:flex py-2'>
                  <div className='w-[14px] h-[14px] bg-[#FFA500] rounded-md mt-1 '>
                    <svg className='w-[10px] h-[10px] fill-[#fff] pt-1 pl-1' xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M256 512A256 256 0 1 0 256 0a256 256 0 1 0 0 512z" /></svg>
                  </div>
                  <p className='text-sm text-[#727272] font-normal ml-2'>No restrictions or hidden costs</p>
                </div>
                <button className='my-2 px-4 py-2 bg-[#90EE90] text-[#325965] text-sm font-bold rounded-t-2xl	rounded-b-2xl	'>Read more about invoicing</button>

              </div>
              <div className='w-[10%]'></div>
            </div>
          </div>
        </div>
      </section>
    </>
  )
}

export default Home