import * as React from 'react'
import { Routes, Route, Router } from "react-router-dom";
import Home from '../home/Home';
import Login from '../login/Login';
import Forgot from '../forgot/Forgot';

const RoutesUrl = () => {
    return (
        <Routes>
            <Route path="/" element={<Home/>} />
            <Route path="login" element={<Login/>} />
            <Route path="forgot" element={<Forgot/>} />

        </Routes>
    )
}
export default RoutesUrl;   