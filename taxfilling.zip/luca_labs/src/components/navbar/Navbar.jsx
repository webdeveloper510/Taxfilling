import React from 'react'

const Header = () => {
  return (
    <>
      <header className="bg-white relative">
        <div className="mx-auto max-w-screen-xl px-4 sm:px-6 w-full m-auto">
          <div className="flex h-16 items-center justify-center w-[100%] m-auto header_responsive">
            <div className='w-[5%]'></div>
            <div className="lg:w-[25%]">
              <a className="block" href="#">
                <img src="Luca Labs.png" alt="" />
              </a>
            </div>
            <div className="hidden md:block lg:w-[50%] md:flex md:items-center">
              <nav aria-label="Global nav_bar">
                <ul className="flex items-center lg:gap-6 text-sm">
                  <li className='lg:flex relative'>
                    <a className="text-[#325965] font-medium transition  pr-2 text-sm" href="#"> The system </a>
                    <span className='float-right'>
                      <a href=""><svg className='w-[13px] h-[13px] fill-[#90EE90] rotate-45 mt-2.5 absolute	right-0' xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512"><path d="M278.6 233.4c12.5 12.5 12.5 32.8 0 45.3l-160 160c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3L210.7 256 73.4 118.6c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0l160 160z" /></svg>
                      </a>
                    </span>
                  </li>
                  <li className='lg:flex relative'>
                    <a className="text-[#325965] font-medium transition  pr-2 text-sm" href="#">Who we are for</a>
                    <span className='float-right'>
                      <a href=""><svg className='w-[13px] h-[13px] fill-[#90EE90] rotate-45 mt-2.5 absolute	right-0' xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512"><path d="M278.6 233.4c12.5 12.5 12.5 32.8 0 45.3l-160 160c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3L210.7 256 73.4 118.6c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0l160 160z" /></svg>
                      </a>
                    </span>
                  </li>
                  <li className='lg:flex relative'>
                    <a className="text-[#325965] font-medium transition  pr-2 text-sm" href="#">Resource</a>
                    <span className='float-right'>
                      <a href=""><svg className='w-[13px] h-[13px] fill-[#90EE90] rotate-45 mt-2.5 absolute	right-0' xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512"><path d="M278.6 233.4c12.5 12.5 12.5 32.8 0 45.3l-160 160c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3L210.7 256 73.4 118.6c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0l160 160z" /></svg>
                      </a>
                    </span>
                  </li>
                  <li className='lg:flex relative'>
                    <a className="text-[#325965] font-medium transition  pr-2 text-sm" href="#">Accountant</a>
                    <span className='float-right'>
                      <a href=""><svg className='w-[13px] h-[13px] fill-[#90EE90] rotate-45 mt-2.5 absolute	right-0' xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512"><path d="M278.6 233.4c12.5 12.5 12.5 32.8 0 45.3l-160 160c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3L210.7 256 73.4 118.6c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0l160 160z" /></svg>
                      </a>
                    </span>
                  </li>
                  <li className='lg:flex relative'>
                    <a className="text-[#325965] font-medium transition  pr-2 text-sm" href="#">Prices</a>
                    <span className='float-right'>
                      <a href=""><svg className='w-[13px] h-[13px] fill-[#90EE90] rotate-45 mt-2.5 absolute	right-0' xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512"><path d="M278.6 233.4c12.5 12.5 12.5 32.8 0 45.3l-160 160c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3L210.7 256 73.4 118.6c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0l160 160z" /></svg>
                      </a>
                    </span>
                  </li>
                </ul>
              </nav>
            </div>
            <div className="flex items-center gap-4 lg:w-[25%]">
              <div className="sm:flex sm:gap-4">
                <a
                  className="sign_in_responsive group inline-block rounded-full bg-gradient-to-r from-[#90EE90] via-[#90EE90] to-[#90EE90]  hover:text-white focus:outline-none  active:text-opacity-75"
                  href="/login"
                >
                  <span
                    className="block rounded-full bg-[#90EE90] text-[#325965] lg:px-5 lg:py-2 text-sm font-bold group-hover:bg-transparent"
                  >
                    Sign In
                  </span>
                </a>
                <div className="hidden sm:flex">
                  <a
                    className="trial_free group inline-block rounded-full bg-gradient-to-r from-[#90EE90] via-[#90EE90] to-[#90EE90] hover:text-white focus:outline-none  active:text-opacity-75"
                    href="#"
                  >
                    <span
                      className="block rounded-full bg-white px-3 py-2 text-sm font-bold group-hover:bg-transparent text-[#325965]"
                    >
                      Try For Free
                    </span>
                  </a>
                </div>
              </div>
              <div className="block md:hidden">
                <button className="rounded bg-gray-100 p-2 text-gray-600 transition hover:text-gray-600/75">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-5 w-5"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                    strokeWidth="2"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" d="M4 6h16M4 12h16M4 18h16" />
                  </svg>
                </button>
              </div>
            </div>

          </div>
        </div>
      </header>
    </>
  )
}

export default Header